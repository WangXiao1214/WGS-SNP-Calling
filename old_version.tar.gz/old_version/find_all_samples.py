import os
import glob
import pandas as pd
from collections import defaultdict
import sys


# 找到目录下的所有样本，并整理成文件，col1:样本名称；col2:fq1的路径；col3:fq2的路径
# ├── kkk
# │   └── sample1
# │       ├── sub_FP500003948_L01_TT069655_1.fq.gz
# │       └── sub_FP500003948_L01_TT069655_2.fq.gz
# └── test_0.05
#     ├── H10098
#     │   ├── sub_FP500003948_L01_H10098_1.fq.gz
#     │   └── sub_FP500003948_L01_H10098_2.fq.gz
#     └── TT069655
#         ├── sub_FP500003948_L01_TT069655_1.fq.gz
#         └── sub_FP500003948_L01_TT069655_2.fq.gz


def find_fastq_pairs(data_dir="data"):
        
    samples = defaultdict(dict)
    
    # 遍历data目录下的所有子目录
    for sample_dir in glob.glob(os.path.join(data_dir, "*")):
        if not os.path.isdir(sample_dir):
            continue
            
        sample_name = os.path.basename(sample_dir)
        
        # 查找该样本目录下的所有fastq文件
        fastq_files = glob.glob(os.path.join(sample_dir, "*_*.fq.gz")) + \
                      glob.glob(os.path.join(sample_dir, "*_*.fastq.gz"))
        
        # 按R1/R2分组
        for fq_file in fastq_files:
            base_name = os.path.basename(fq_file)
            if "_1.fq.gz" in base_name or "_1.fastq.gz" in base_name:
                samples[sample_name]["fq1"] = fq_file
            elif "_2.fq.gz" in base_name or "_2.fastq.gz" in base_name:
                samples[sample_name]["fq2"] = fq_file
    
    return samples

def create_sample_table(sample_dict, output_file="samples.tsv"):
    """
    从样本字典创建样本表
    
    参数:
        sample_dict: find_fastq_pairs()返回的字典
        output_file: 输出样本表文件路径
    """
    # 确保列顺序为 sample, fq1, fq2
    columns_order = ["sample", "fq1", "fq2"]
    
    records = []
    for sample, paths in sample_dict.items():
        records.append({
            "sample": sample,
            "fq1": paths.get("fq1", ""),
            "fq2": paths.get("fq2", "")
        })
    
    df = pd.DataFrame(records)[columns_order]  # 确保列顺序
    df.to_csv(output_file, sep="\t", index=False)
    print(f"样本表已保存到 {output_file}")

if __name__ == "__main__":
    # 1. 扫描data目录获取所有样本
    inputdir = sys.argv[1]
    samples = find_fastq_pairs(inputdir)
    
    # 2. 检查是否找到样本
    if not samples:
        print("错误: 在data目录下未找到任何样本!")
        exit(1)
    
    # 3. 创建样本表
    create_sample_table(samples)
    
    # 4. 打印样本表内容供检查
    print(pd.read_csv("samples.tsv", sep="\t").to_string(index=False))
