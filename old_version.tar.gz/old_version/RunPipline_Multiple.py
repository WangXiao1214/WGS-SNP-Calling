#!/usr/bin/env python3
"""
NGS Analysis Pipeline: FASTQ-to-VCF with Quality Control
Steps: fastp (QC) -> BWA (alignment) -> Sambamba (markdup) -> Mosdepth (coverage) -> GATK (variant calling)
"""

import os
import subprocess
import argparse
from datetime import datetime
import logging
import glob
from multiprocessing import Pool

PL = "ILLUMINA"  

# Tool paths (modify according to your environment)
FASTP = "/mnt/beegfs/Research/Software/fastp/fastp"
BWA = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/bwa"
SAMTOOLS = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/samtools"
MOSDEPTH = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/mosdepth"
MULTIQC = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/multiqc"
# PICARD = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/"
SAMBAMBA = "/mnt/beegfs/mashujie/miniconda3/envs/meth_env/bin/sambamba"
GATK = "/mnt/beegfs/Research/Software/gatk-4.1.8.1/gatk"



logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    filename='pipeline.log'
)
logger = logging.getLogger()

def find_samples(input_dir):

    samples = {}
    
    for sample_dir in os.listdir(input_dir):
        dir_path = os.path.join(input_dir, sample_dir)
        
        if not os.path.isdir(dir_path):
            continue
            
        sample_id = sample_dir
        
        r1_files = glob.glob(os.path.join(dir_path, "*_1.fq.gz"))
        r2_files = glob.glob(os.path.join(dir_path, "*_2.fq.gz"))
        
        if len(r1_files) == 1 and len(r2_files) == 1:
            samples[sample_id] = {
                'original_dir': dir_path,
                'original_r1': r1_files[0],
                'original_r2': r2_files[0],
                'original_files': [r1_files[0], r2_files[0]]
            }
            logger.info(f"Found sample {sample_id} with files: {r1_files[0]} and {r2_files[0]}")
        elif len(r1_files) > 1 or len(r2_files) > 1:
            logger.error(f"Multiple R1/R2 files found in {sample_id} (expected only one pair)")
        else:
            logger.error(f"Missing R1/R2 files in {sample_id} (expected one pair)")
    
    return samples

def run_command(cmd, desc=None):

    if desc:
        logger.info(f"Running: {desc}")
    logger.info(f"Command: {cmd}")
    
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        logger.info("Command completed successfully")
        return result
    except subprocess.CalledProcessError as e:
        logger.error(f"Command failed with return code {e.returncode}")
        logger.error(f"Error output: {e.stderr}")
        raise

def run_fastp(input1, input2, output_dir, sample_id, threads=4):

    logger.info(f"Starting fastp QC for {sample_id}")
    
    clean1 = os.path.join(output_dir, f"{sample_id}_clean_1.fq.gz")
    clean2 = os.path.join(output_dir, f"{sample_id}_clean_2.fq.gz")
    json_report = os.path.join(output_dir, f"{sample_id}_fastp.json")
    html_report = os.path.join(output_dir, f"{sample_id}_fastp.html")
    
    cmd = (
        f"{FASTP} --in1 {input1} --in2 {input2} "
        f"--out1 {clean1} --out2 {clean2} "
        f"--json {json_report} --html {html_report} "
        f"--thread {threads} --verbose"
    )
    
    run_command(cmd, "fastp quality control")
    
    return clean1, clean2

def run_multiqc(output_dir, analysis_name="my_analysis"):

    multiqc_report_dir = os.path.join(output_dir, "multiqc_report")
    os.makedirs(multiqc_report_dir, exist_ok=True)

    cmd = (
        f"{MULTIQC} {output_dir} "
        f"--outdir {multiqc_report_dir} "
        f"--filename {analysis_name} "
        f"--title {analysis_name} "
        f"--interactive" 
    )

    try:
        run_command(cmd, "MultiQC report generation")
        report_path = os.path.join(multiqc_report_dir, f"{analysis_name}.html")
        logger.info(f"MultiQC report generated: {report_path}")
        return report_path
    except subprocess.CalledProcessError as e:
        logger.error(f"MultiQC failed: {e.stderr}")
        raise

def run_bwa_mem_and_markdup(reference, read1, read2, output_dir, sample_id, threads=4, remove_duplicates=False,):

    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    logger.info(f"Starting alignment pipeline for {sample_id}")
    
    # 1. BWA-MEM alignment directly to sorted BAM
    sorted_bam_output = os.path.join(output_dir, f"{sample_id}.sorted.bam")
    
    # Run BWA-MEM and pipe directly to samtools sort
    bwa_sort_cmd = (
        f"{BWA} mem -K 10000000 -M -Y -t {threads} "
        f"-R '@RG\\tID:{sample_id}\\tSM:{sample_id}\\tPL:{PL}' "
        f"{reference} {read1} {read2} | "
        # sambamba加入管道符会报错,即使添加/dev/stdin,所以只能用samtools
        f"{SAMTOOLS} sort -t {threads} -o {sorted_bam_output}"
    )
    run_command(bwa_sort_cmd, "BWA-MEM to sorted BAM")

    # Index sorted BAM
    samtools_index_cmd = f"{SAMBAMBA} index {sorted_bam_output}"
    run_command(samtools_index_cmd, "Index sorted BAM")
    
    
    # 2. Sambamba mark duplicates
    markdup_bam_output = os.path.join(output_dir, f"{sample_id}.markdup.bam")
    metrics_file = os.path.join(output_dir, f"{sample_id}.markdup_metrics.txt")
    
    sambamba_cmd = (
        f"{SAMBAMBA} markdup "
        f"--t {threads} "
        f"--overflow-list-size 1000000 "
        f"--hash-table-size 1000000 "
        f"{'--remove-duplicates' if remove_duplicates else ''} "
        f"{sorted_bam_output} "
        f"{markdup_bam_output} "
        f"2> {metrics_file}"
    )
    
    try:
        run_command(sambamba_cmd, "Sambamba mark duplicates")
        
        # Index marked duplicate BAM
        run_command(f"{SAMBAMBA} index {markdup_bam_output}", "Index marked BAM")
        
        # Remove intermediate sorted BAM (optional)
        os.remove(sorted_bam_output)
        os.remove(f"{sorted_bam_output}.bai")
        
        logger.info(f"Alignment pipeline completed for {sample_id}")
        return markdup_bam_output
        
    except subprocess.CalledProcessError as e:
        logger.error(f"Pipeline failed for {sample_id}. Error:\n{e.stderr}")
        raise

def run_gatk_haplotypecaller(input_bam, reference, output_dir, sample_id, intervals=None, threads=4):

    raw_vcf = os.path.join(output_dir, f"{sample_id}.g.vcf.gz")

    temp_dir = os.path.join(output_dir, f"temp_{sample_id}")
    os.makedirs(temp_dir, exist_ok=True)
    
    cmd = (
        f"{GATK} --java-options '-Xmx30g -Djava.io.tmpdir={temp_dir}' HaplotypeCaller "
        f"-R {reference} "
        f"-I {input_bam} "
        f"-O {raw_vcf} "
        f"--native-pair-hmm-threads {threads} "
        f"--emit-ref-confidence GVCF "  
        f"{'--intervals ' + intervals if intervals else ''}"
    )

    try:
        run_command(cmd, "GATK HaplotypeCaller")
        return raw_vcf
    except subprocess.CalledProcessError as e:
        logger.error(f"GATK HaplotypeCaller failed: {e.stderr}")
        raise

'''
def collect_gvcfs(output_base_dir):
    """收集所有样本的GVCF文件路径"""
    gvcf_list = []
    samples_dir = os.path.join(output_base_dir, "samples")
    
    for sample_id in os.listdir(samples_dir):
        sample_dir = os.path.join(samples_dir, sample_id)
        if not os.path.isdir(sample_dir):
            continue
            
        gvcf_path = os.path.join(sample_dir, f"{sample_id}.g.vcf.gz")
        if os.path.exists(gvcf_path):
            gvcf_list.append(gvcf_path)
            logger.info(f"Found GVCF for {sample_id}: {gvcf_path}")
        else:
            logger.warning(f"Missing GVCF for {sample_id}")
    
    return gvcf_list

def run_joint_calling(output_base_dir, reference, intervals=None, threads=4):
    """
    执行联合分析流程：
    1. 收集所有样本GVCF
    2. CombineGVCFs
    3. GenotypeGVCFs
    4. 变异过滤
    """
    # Create directory
    joint_dir = os.path.join(output_base_dir, "joint_calling")
    os.makedirs(joint_dir, exist_ok=True)
    logger.info(f"Starting joint calling analysis in {joint_dir}")

    # Get all the gvcf files
    gvcf_list = collect_gvcfs(output_base_dir)
    
    if not gvcf_list:
        raise ValueError("No GVCF files found for joint calling")

    # Merge gvcf files
    combined_gvcf = os.path.join(joint_dir, "combined.g.vcf.gz")
    if len(gvcf_list) > 1:
        logger.info(f"Combining {len(gvcf_list)} GVCFs")
        
        # Create the gvcf file
        list_file = os.path.join(joint_dir, "gvcf_list.txt")
        with open(list_file, "w") as f:
            for gvcf in gvcf_list:
                f.write(f"{gvcf}\n")
        
        cmd = (
            f"{GATK} --java-options '-Xmx8g' CombineGVCFs "
            f"-R {reference} ")

        for gvcf in gvcf_list:
            cmd += f"--variant {gvcf} "

        cmd += (
            f"-O {combined_gvcf} "
            f"{'--intervals ' + intervals if intervals else ''}")

        run_command(cmd, "CombineGVCFs")
    else:
        # if only one samples 
        logger.info("Single sample detected, skipping CombineGVCFs")
        combined_gvcf = gvcf_list[0]

    # Genotype GVCFs
    raw_vcf = os.path.join(joint_dir, "joint_genotyped.vcf.gz")
    cmd = (
        f"{GATK} --java-options '-Xmx8g' GenotypeGVCFs "
        f"-R {reference} "
        f"-V {combined_gvcf} "
        f"-O {raw_vcf} "
        f"{'--intervals ' + intervals if intervals else ''}"
    )
    run_command(cmd, "GenotypeGVCFs")


    # filter
    logger.info("Starting variant filtering")
    
    # SNP
    filtered_snps = os.path.join(joint_dir, "filtered_snps.vcf.gz")
    cmd = (
        f"{GATK} --java-options '-Xmx4g' VariantFiltration "
        f"-R {reference} "
        f"-V {raw_vcf} "
        f"-O {filtered_snps} "
        f"--filter-name 'SNP_FILTER' "
        f"--filter-expression 'QD < 2.0 || FS > 60.0 || MQ < 40.0 || MQRankSum < -12.5 || ReadPosRankSum < -8.0'"
    )
    run_command(cmd, "SNP filtering")

    # INDEL
    filtered_indels = os.path.join(joint_dir, "filtered_indels.vcf.gz")
    cmd = (
        f"{GATK} --java-options '-Xmx4g' VariantFiltration "
        f"-R {reference} "
        f"-V {raw_vcf} "
        f"-O {filtered_indels} "
        f"--filter-name 'INDEL_FILTER' "
        f"--filter-expression 'QD < 2.0 || FS > 200.0 || ReadPosRankSum < -20.0'"
    )
    run_command(cmd, "INDEL filtering")
    
    logger.info(f"Joint calling completed. Final results in {joint_dir}")
    return {
        "combined_gvcf": combined_gvcf,
        "raw_vcf": raw_vcf,
        "filtered_snps": filtered_snps,
        "filtered_indels": filtered_indels
    }
'''

def run_mosdepth(input_bam, output_dir, sample_id, threads=4):

    output_prefix = os.path.join(output_dir, sample_id)
    
    cmd = (
        f"{MOSDEPTH} --threads {threads} "
        f"--fast-mode "  
        f"--by 1000 "    
        f"{output_prefix} "
        f"{input_bam}"
    )
    
    try:
        run_command(cmd, "Mosdepth depth calculation")
        logger.info(f"Mosdepth output files prefix: {output_prefix}.*")
        return output_prefix
    except subprocess.CalledProcessError as e:
        logger.error(f"Mosdepth failed for {sample_id}: {e.stderr}")
        raise

def process_sample(sample_id, sample_info, reference, output_base_dir, threads):

    logger.info(f"Processing sample: {sample_id}")
    start_time = datetime.now()
    

    sample_output_dir = os.path.join(output_base_dir, "samples", sample_id)
    os.makedirs(sample_output_dir, exist_ok=True)
    

    with open(os.path.join(sample_output_dir, "source_files.txt"), "w") as f:
        f.write(f"Original R1: {sample_info['original_r1']}\n")
        f.write(f"Original R2: {sample_info['original_r2']}\n")
    
    try:

        clean1, clean2 = run_fastp(
            sample_info['original_r1'], sample_info['original_r2'],
            sample_output_dir, sample_id,
            threads=threads
        )
        
        markdup_bam_file = run_bwa_mem_and_markdup(
            reference=reference,
            read1=clean1,
            read2=clean2,
            output_dir=sample_output_dir,
            sample_id=sample_id,
            threads=threads
        )

        run_mosdepth(
            input_bam=markdup_bam_file,
            output_dir=sample_output_dir,
            sample_id=sample_id,
            threads=threads
        )

        run_gatk_haplotypecaller(
            input_bam=markdup_bam_file,
            reference=reference,
            output_dir=sample_output_dir,
            sample_id=sample_id,
            threads=threads
        )

        runtime = datetime.now() - start_time
        logger.info(f"Sample {sample_id} processed successfully")
        logger.info(f"Runtime: {runtime}")
        logger.info(f"Generated clean files: {clean1} and {clean2}")
        

        with open(os.path.join(output_base_dir, "processed_samples.txt"), "a") as f:
            f.write(f"{sample_id}\t{sample_info['original_r1']}\t{sample_info['original_r2']}\t{clean1}\t{clean2}\n")
        
    except Exception as e:
        logger.error(f"Failed to process sample {sample_id}: {str(e)}")
        raise

def process_sample_wrapper(sample_id, sample_info, reference, output_dir, threads):
    
    # 为每个进程创建独立日志文件
    log_file = os.path.join(output_dir, "samples", sample_id, f"{sample_id}.log")
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger()
    
    try:
        return process_sample(sample_id, sample_info, reference, output_dir, threads)
    except Exception as e:
        logger.error(f"Sample {sample_id} failed: {str(e)}", exc_info=True)
        raise

def main():

    parser = argparse.ArgumentParser(description="Fastp quality control pipeline (preserves original files)")
    parser.add_argument("-i", "--input_dir", required=True,
                       help="Input directory containing sample directories")
    parser.add_argument("-r", "--reference", required=True,
                       help="Path to hg19 reference genome (index should exist) eg:hg19.fa")
    parser.add_argument("-o", "--output_dir", required=True,
                       help="Base output directory (will be created)")
    parser.add_argument("-t", "--threads", type=int, default=4,
                       help="Number of threads per sample (default: 4)")
    parser.add_argument("--max-jobs", type=int, default=4,
                   help="最大并行样本数 (default: 4)")
    
    args = parser.parse_args()
    

    os.makedirs(args.output_dir, exist_ok=True)
    os.makedirs(os.path.join(args.output_dir, "samples"), exist_ok=True)
    

    with open(os.path.join(args.output_dir, "processed_samples.txt"), "w") as f:
        f.write("SampleID\tOriginal_R1\tOriginal_R2\tClean_R1\tClean_R2\n")
    

    samples = find_samples(args.input_dir)
    if not samples:
        raise ValueError(f"No valid samples found in {args.input_dir}")
    
    
    # 设置并行进程数（不超过CPU核心数）
    max_processes = min(args.max_jobs, os.cpu_count(), len(samples))
    logger.info(f"Starting pipeline with {max_processes} parallel jobs")

    # 每个样本的参数元组列表
    tasks = [
        (sample_id, sample_info, args.reference, args.output_dir, args.threads)
        for sample_id, sample_info in samples.items()
    ]

    # 并行处理
    with Pool(processes=max_processes) as pool:
        results = pool.starmap(process_sample_wrapper, tasks)



    logger.info(f"Starting fastp pipeline with {len(samples)} samples")
    logger.info(f"Original files will be preserved, all outputs will go to {args.output_dir}")
    total_start = datetime.now()
    
    '''
    run_joint_calling(
        output_base_dir=args.output_dir,
        reference=args.reference,
        threads=args.threads
    )

    '''
    
    try:
        multiqc_report = run_multiqc(
            output_dir=args.output_dir,  
            analysis_name="NGS_QC_Report"
        )
        logger.info(f"Pipeline completed. Final report: {multiqc_report}")
    except Exception as e:
        logger.error(f"Pipeline finished with errors. MultiQC may be incomplete: {str(e)}")
    
    total_runtime = datetime.now() - total_start
    logger.info(f"Pipeline completed for all samples")
    logger.info(f"Total runtime: {total_runtime}")
    logger.info(f"Processed samples: {list(samples.keys())}")
    logger.info(f"Original files were preserved, all results are in {args.output_dir}")

if __name__ == "__main__":
    main()