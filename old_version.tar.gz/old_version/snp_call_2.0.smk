# Snakefile
# original version fq --> all_sample_vcf
configfile: "/mnt/beegfs/Research/Pipeline/SNPCalling/config_v2.0.yaml"

import os
import pandas as pd
import glob

samples = pd.read_table(config["sample_table"]).set_index("sample", drop=False)
sample_name = samples.index.unique().tolist()

with open(config["interval"]) as f:
    intervals = [line.strip().split("\t")[0] + "_" + line.strip().split("\t")[1] + "_" + line.strip().split("\t")[2] 
                 for line in f if line.strip()]

# 定义最终输出
rule all:
    input:
        expand("results/{sample}/{sample}.html", sample = sample_name),
        expand("results/{sample}/{sample}.markdup.bam.bai", sample = sample_name),
        expand("results/stats/{sample}.stats.txt", sample = sample_name),
        expand("results/{sample}/{sample}.mosdepth.global.dist.txt", sample = sample_name),
        expand("results/{sample}/per_sample_merged/{sample}.g.vcf.gz", sample=sample_name),
        expand("results/stats/{sample}.idxstats.txt", sample = sample_name),
        expand("results/coverage/{sample}.coverage_thresholds.txt", sample=sample_name),
        "results/multi_sample_merged/combined.g.vcf.gz",
        "results/final/genotyped.vcf.gz",
        "results/multiqc_report.html"  # 添加MultiQC报告

# 1. 原始数据质量控制
rule fastp:
    input:
        r1 = lambda wildcards: samples.loc[wildcards.sample, "fq1"],
        r2 = lambda wildcards: samples.loc[wildcards.sample, "fq2"]
    output:
        r1 = "results/{sample}/{sample}_1.fq.gz",
        r2 = "results/{sample}/{sample}_2.fq.gz",
        html = "results/{sample}/{sample}.html",
        json = "results/{sample}/{sample}.json"
    resources:
        threads = 8,
        mem_gb = 32,
        walltime="4:00:00"
    shell:
        """
        {config[software][fastp][path]} \
        --in1 {input.r1} --in2 {input.r2} \
        --out1 {output.r1} --out2 {output.r2} \
        --json {output.json} --html {output.html}
        """

# 2. 比对到参考基因组并且排序
rule bwa_mem:
    input:
        r1=rules.fastp.output.r1,
        r2=rules.fastp.output.r2,
        ref=config["reference"]["genome"],
        ref_idx=config["reference"]["index"]
    output:
        "results/{sample}/{sample}_sorted.bam"
    params:
        extra=config["software"]["bwa"]["params"],
        PL="ILLUMINA"
    resources:
        mem_gb=60,
        walltime="10:00:00"
    threads: config["params"]["threads"]["bwa"]
    shell:
        """
        {config[software][bwa][path]} mem -K 10000000 {params.extra} -t {threads} \
        -R '@RG\\tID:{wildcards.sample}\\tSM:{wildcards.sample}\\tPL:{params.PL}' \
        {input.ref} {input.r1} {input.r2} | \
        {config[software][samtools][path]} sort -t {threads} -o {output}
        """


rule bam_stats:
    input:
        bam = "results/{sample}/{sample}_sorted.bam"
    output:
        idxstats = "results/stats/{sample}.idxstats.txt",
        flagstat = "results/stats/{sample}.flagstat.txt",
        stats = "results/stats/{sample}.stats.txt",
    params:
        ref_path = config["reference"]["genome"],
    threads: 16
    resources:
        # threads=4,
        mem_gb=30,
        walltime="1:00:00"
    log:
        "logs/stats/{sample}.stats.log"
    shell:
        """
        # 创建输出目录
        mkdir -p results/stats
        mkdir -p logs/stats
        
        # Samtools索引统计 - 使用BAM
        {config[software][samtools][path]} idxstats {input.bam} > {output.idxstats} 2>> {log}
        
        # Samtools标志统计 - 使用BAM
        {config[software][samtools][path]} flagstat {input.bam} > {output.flagstat} 2>> {log}
        
        # Samtools基本统计 - 使用BAM
        {config[software][samtools][path]} stats --reference {params.ref_path} {input.bam} > {output.stats} 2>> {log}
        """

rule genome_coverage:
    input:
        bam = "results/{sample}/{sample}_sorted.bam"  # 修正文件名一致性
    output:
        # 按染色体的覆盖度分析
        per_chrom = "results/coverage/{sample}.per_chrom.txt",
        # 不同覆盖度阈值的统计
        thresholds = "results/coverage/{sample}.coverage_thresholds.txt"
    params:
        ref_path = config["reference"]["genome"],
        # 覆盖度阈值，例如1X, 5X, 10X, 20X, 30X
        thresholds = "1,5,10,20,30"
    threads: 8
    resources:
        # threads=4,
        mem_gb=30,
        walltime="2:00:00"
    log:
        "logs/coverage/{sample}.coverage.log"
    shell:
        """
        # 创建输出目录
        mkdir -p results/coverage
        mkdir -p logs/coverage
        
        # 计算每条染色体的平均覆盖度 - 使用BAM
        {config[software][samtools][path]} coverage {input.bam} > {output.per_chrom} 2>> {log}
        
        # 计算不同覆盖度阈值下的基因组比例
        echo "Coverage_Threshold Genome_Fraction" > {output.thresholds}
        
        # 首先计算基因组大小
        genome_size=$({config[software][samtools][path]} idxstats {input.bam} | cut -f2 | awk '{{sum+=$1}} END{{print sum}}')
        
        # 使用bedtools genomecov计算不同阈值的覆盖度 - 使用BAM
        for threshold in $(echo {params.thresholds} | tr ',' ' '); do
            # 计算大于等于该阈值的基因组比例
            fraction=$({config[software][bedtools][path]} genomecov -ibam {input.bam} \
                       -g <({config[software][samtools][path]} faidx {params.ref_path} | cut -f1,2) \
                       -bg | awk -v t="$threshold" -v gs="$genome_size" '{{if($4>=t){{bases+=$3-$2}}}} END{{print bases/gs}}')
            
            echo "$threshold $fraction" >> {output.thresholds}
        done
        """

rule markdup:
    input:
        "results/{sample}/{sample}_sorted.bam"
    output:
        bam="results/{sample}/{sample}.markdup.bam",
        metrics="results/{sample}/{sample}.markdup_metrics.txt"
    threads: config["params"]["threads"]["markdup"]
    resources:
        # threads=4,
        mem_gb=30,
        walltime="1:00:00"
    shell:
        """
        {config[software][sambamba][path]} markdup \
        -t {threads} \
        --hash-table-size 1000000 \
        --overflow-list-size 1000000 \
        --remove-duplicates \
        {input} \
        {output.bam} 2> {output.metrics}
        """

rule index_bam:
    input:
        "results/{sample}/{sample}.markdup.bam"
    output:
        "results/{sample}/{sample}.markdup.bam.bai"
    threads: 8
    resources:
        # threads=4,
        mem_gb=30,
        walltime="1:00:00"
    shell:
        """
        {config[software][sambamba][path]} index -t {threads} {input}
        """


rule mosdepth:
    input:
        bam="results/{sample}/{sample}.markdup.bam",
        bai="results/{sample}/{sample}.markdup.bam.bai"
    output:
        "results/{sample}/{sample}.mosdepth.global.dist.txt",
        "results/{sample}/{sample}.mosdepth.region.dist.txt",
        "results/{sample}/{sample}.mosdepth.summary.txt",
        "results/{sample}/{sample}.per-base.bed.gz",
        "results/{sample}/{sample}.per-base.bed.gz.csi",
        "results/{sample}/{sample}.regions.bed.gz",
        "results/{sample}/{sample}.regions.bed.gz.csi"
    params:
        prefix="results/{sample}/{sample}"
    threads: 4
    resources:
        # threads=4,
        mem_gb=30,
        walltime="1:00:00"
    shell:
        """
        {config[software][mosdepth][path]} --threads {threads} \
        --fast-mode \
        --by 100000 \
        --thresholds 1,5,10,15,10,25,30 \
        {params.prefix} \
        {input.bam}
        """

rule gatk_haplotype_caller:
    input:
        bam = rules.markdup.output.bam,
        bai = rules.index_bam.output,
        ref = config["reference"]["genome"],
        intervals = config["interval"]
    output:
        temp("results/{sample}/gvcf/{interval}.g.vcf.gz")
        # temp("results/{sample}/gvcf/{interval}.g.vcf.gz.tbi")
    params:
        java_opts = config["software"]["gatk"]["java_opts"],
        interval = lambda wildcards: (
            f"{wildcards.interval.split('_')[0]}:"
            f"{wildcards.interval.split('_')[1]}-"
            f"{wildcards.interval.split('_')[2]}"
        )
    threads: 4
    resources:
        # threads=4,
        mem_gb=40,
        walltime="5:00:00"
    shell:
        """
        interval_start=$(echo {wildcards.interval} | cut -d'_' -f2)
        interval_end=$(echo {wildcards.interval} | cut -d'_' -f3)
        interval_name=$(echo {wildcards.interval} | cut -d'_' -f1)_$interval_start-$interval_end

        {config[software][gatk][path]} --java-options "{params.java_opts}" \
        HaplotypeCaller \
        -R {input.ref} \
        -I {input.bam} \
        -O {output} \
        -L "{params.interval}" \
        -ERC GVCF
        """


rule merge_single_sample:
    input:
        gvcfs = expand("results/{sample}/gvcf/{interval}.g.vcf.gz",
                      sample=sample_name,
                      interval=intervals),
        ref = config["reference"]["genome"]
    output:
        "results/{sample}/per_sample_merged/{sample}.g.vcf.gz"
    params:
        java_opts = config["software"]["gatk"]["java_opts"],
        variants = lambda wc: ['--variant ' + gvcf 
                             for gvcf in glob.glob(f"results/{wc.sample}/gvcf/*.g.vcf.gz")]
    threads: 4
    resources:
        # threads=4,
        mem_gb=30,
        walltime="3:00:00"
    shell:
        """
        {config[software][gatk][path]} --java-options "{params.java_opts}" \
        CombineGVCFs \
        -R {input.ref} \
        {params.variants} \
        -O {output}
         
        # delete the gvcf files
        rm -f results/{wildcards.sample}/gvcf/*.g.vcf.gz || true
        rm -f results/{wildcards.sample}/gvcf/*.g.vcf.gz.tbi || true
        """

rule combine_multi_sample:
    input:
        gvcfs = expand("results/{sample}/per_sample_merged/{sample}.g.vcf.gz", sample=sample_name),
        ref = config["reference"]["genome"]
    output:
        temp("results/multi_sample_merged/combined.g.vcf.gz")
    params:
        java_opts = config["software"]["gatk"]["java_opts"]
    resources:
        # threads=4,
        mem_gb=30,
        walltime="2:00:00"
    threads: 8
    shell:
        """
        variants=""
        for gvcf in {input.gvcfs}; do
            variants="$variants --variant $gvcf"
        done

        {config[software][gatk][path]} --java-options "{params.java_opts}" \
        CombineGVCFs \
        -R {input.ref} \
        $variants \
        -O {output}
        """

rule genotype_gvcfs:
    input:
        combined = rules.combine_multi_sample.output,
        ref = config["reference"]["genome"],
    output:
        "results/final/genotyped.vcf.gz"
    params:
        java_opts = config["software"]["gatk"]["java_opts"],
    threads: 8
    resources:
        # threads=4,
        mem_gb=30,
        walltime="2:00:00"
    shell:
        """
        {config[software][gatk][path]} --java-options "{params.java_opts}" \
        GenotypeGVCFs \
        -R {input.ref} \
        -V {input.combined} \
        -O {output}
        """

rule multiqc:
    input:
        fastp_reports = expand("results/{sample}/{sample}.html", sample = sample_name),
        fastp_jsons = expand("results/{sample}/{sample}.json", sample = sample_name),
        markdup_metrics = expand("results/{sample}/{sample}.markdup_metrics.txt", sample = sample_name),
        mosdepth_reports = expand("results/{sample}/{sample}.mosdepth.summary.txt", sample = sample_name),
        idxstats = expand("results/stats/{sample}.idxstats.txt", sample = sample_name),
        flagstat = expand("results/stats/{sample}.flagstat.txt", sample = sample_name),
        stats = expand("results/stats/{sample}.stats.txt", sample = sample_name)
    output:
        "results/multiqc_report.html",
    params:
        title = "'multiqc_report'",
    threads: 1
    resources:
        # threads=1,
        mem_gb=30,
        walltime="1:00:00"
    log:
        "logs/multiqc.log"
    shell:
        """
        {config[software][multiqc][path]} "results" \
        --outdir "results" \
        --title {params.title} \
        --filename {params.title} \
        --interactive \
        >> {log} 2>&1
        """


