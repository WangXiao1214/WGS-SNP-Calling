mkdir results
cut -f1,2 /mnt/beegfs/Research/Database/hg19/GRCH37/GRCh37_p13_ncbi.fa.fai | awk '{{print $1 "\t1\t" $2}}' > results/50mb_intervals.bed
/mnt/beegfs/Clinical/users/wenyanhua/soft/current/bedtools makewindows -b results/50mb_intervals.bed -w 50000000 | awk 'BEGIN{{FS=OFS="\t"}} {{if ($2==0) $2=1; print}}' > results/50mb_intervals.bed.tmp && mv results/50mb_intervals.bed.tmp results/intervals.bed
